# caro-cutzzz

One-page site for Alexander Caro, barber in Tillsonburg, Ontario.

Static HTML/CSS/JS. No build step, no dependencies.

## Running it

Open `index.html` in a browser, or serve the folder:

```
python3 -m http.server 8000
```

## Deploying to GitHub Pages

Push to a repo, then Settings → Pages → Source: `main` branch, root folder.

Before the first deploy, open `index.html` and replace `USERNAME` in the two
`og:` tags with your GitHub username. Those need absolute URLs or link previews
break when the site gets shared on Instagram or TikTok.

## Structure

```
index.html
404.html
assets/
  css/style.css
  js/main.js
  fonts/          Archivo Black, DM Mono, Newsreader (latin subsets)
  img/            photos, avatars, share card, icons
```

## Notes

- Fonts are self-hosted. Google Fonts gets blocked or throttled inside the
  Instagram and TikTok browsers, and the fallback stack looked bad there.
- `assets/img/share.jpg` is the 1200x630 link preview card.
- Dark mode follows the system setting.
- Prices live in the `.plist` block in `index.html`. Update them there and in
  the price graphic if it changes.
